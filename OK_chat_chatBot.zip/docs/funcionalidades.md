# Documentación técnica – OK_chat

## Funcionalidades esperadas del sistema

- El visitante puede escribir preguntas y recibir respuestas automáticas.
- El administrador puede cargar nuevas preguntas/respuestas.
- Todas las preguntas están asociadas con una o más respuestas posibles.
- El sistema puede ser entrenado manualmente a partir de datos cargados.

## Reglas básicas

- Cada pregunta tiene al menos una respuesta asociada.
- Las respuestas pueden actualizarse o eliminarse sin afectar la pregunta.
- Un panel de administrador permite gestionar el contenido.